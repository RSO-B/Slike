create function compose_session_replication_role(role text)
  returns text
security definer
language plpgsql
as $$
DECLARE
                curr_val text := 'unset';
        BEGIN
                EXECUTE 'SET session_replication_role = ' || quote_literal(role);
                EXECUTE 'SHOW session_replication_role' INTO curr_val;
                RETURN curr_val;
        END
$$;

alter function compose_session_replication_role(text)
  owner to focker;

