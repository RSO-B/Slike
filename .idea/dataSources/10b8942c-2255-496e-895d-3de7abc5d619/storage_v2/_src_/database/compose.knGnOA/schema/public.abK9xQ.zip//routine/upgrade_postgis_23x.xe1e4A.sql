create function upgrade_postgis_23x()
  returns void
security definer
SET search_path = public, pg_temp
language plpgsql
as $$
DECLARE ver TEXT;
    BEGIN
            SELECT version INTO ver FROM pg_available_extension_versions WHERE name = 'postgis' AND version LIKE '2.3%';
            EXECUTE 'ALTER EXTENSION postgis UPDATE TO ' || quote_literal(ver);
    END;
$$;

alter function upgrade_postgis_23x()
  owner to focker;

