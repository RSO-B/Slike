create function pg_kill_connection(integer)
  returns boolean
security definer
language sql
as $$
select pg_terminate_backend($1);
$$;

alter function pg_kill_connection(integer)
  owner to focker;

